UPDATE peoplecorp_case_study_crmiguez 
SET heroe_id = numberInput3.value,
heroe = textInput3.value
heroe_motivo = textInput4.value
WHERE empleado_id = parameter_name.empleado_id
