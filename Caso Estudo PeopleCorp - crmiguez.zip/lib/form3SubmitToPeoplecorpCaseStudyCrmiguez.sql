INSERT INTO peoplecorp_case_study_crmiguez(
  fecha_antiguedad, nombre, apellido_1, apellido_2,
  fecha_nacimiento,
  puesto,
  departamento,
  correo_empleado,
  contrasena)
VALUES ({{  form3.data }}); 