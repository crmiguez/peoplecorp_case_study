UPDATE peoplecorp_case_study_crmiguez 
SET nombre = {{  textArea21.value }},
apellido_1 = {{ textArea22.value }},
apellido_2 = {{  textArea23.value }},
fecha_nacimiento = {{ date7.dateFormat }},
departamento = {{ textArea24.value }},
puesto = {{ textArea25.value }},
otros = {{ textArea27.value }},
correo_empleado = {{ textArea31.value }},
contrasena = {{ textArea26.value }},
heroe = {{ textArea29.value }},
heroe_motivo = {{ textArea30.value }}
WHERE empleado_id = parameter_name.empleado_id