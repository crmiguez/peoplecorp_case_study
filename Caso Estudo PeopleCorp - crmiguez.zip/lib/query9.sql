SELECT *
FROM peoplecorp_case_study_crmiguez ;