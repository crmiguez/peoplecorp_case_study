UPDATE peoplecorp_case_study_crmiguez 
SET nombre = '',
  apellido_1 = '',
  apellido_2 = '',
  fecha_nacimiento = ''
  correo_empleado = '',
  otros = '',
  departamento = '',
  puesto = '',
  contrasena = ''
WHERE empleado_id = {{  self.empleado_id }}