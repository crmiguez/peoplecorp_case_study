SELECT * FROM peoplecorp_case_study_crmiguez
WHERE correo_empleado = {{ self.correo_empleado}} AND contrasena = {{ self.contrasena }};